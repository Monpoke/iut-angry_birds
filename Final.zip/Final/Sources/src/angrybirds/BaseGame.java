/*
 *  Projet AngryBirds
 *  DUT Informatique - 2e
 */
package angrybirds;

/**
 *
 * @author Pierre
 */
abstract class BaseGame {
    
}
