/*
 *  Projet AngryBirds
 *  DUT Informatique - 2e
 */
package angrybirds;

/**
 *
 * @author Pierre
 */
public interface AngryEvent {
    public void notif(Object data);
}
