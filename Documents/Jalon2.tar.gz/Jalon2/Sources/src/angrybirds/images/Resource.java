/*
 *  Projet Angry Birds
 */
package angrybirds.images;

import java.awt.Image;

/**
 *
 * @author Pierre
 */
public interface Resource {
    
    public Image getImage();
    
}
