/*
 *  Projet AngryBirds
 *  DUT Informatique - 2e
 */
package angrybirds.events;

/**
 *
 * @author Pierre
 */
public interface AngryEvent {
    public void notif(Object data);
}
