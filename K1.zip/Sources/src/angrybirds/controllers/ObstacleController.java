
/*
 *  Projet Angry Birds
 */
package angrybirds.controllers;

import angrybirds.models.GameObjectModel;
import angrybirds.models.ObstacleModel;

/**
 *
 * @author Pierre
 */
public class ObstacleController extends GameObjectController {

    public ObstacleController(GameObjectModel model) {
        super(model);
    }

    @Override
    public void update() {
    	super.update();
    	
    	
    }
    
}

