package angrybirds.motors;

import angrybirds.views.GameObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Pierre on 04/01/2016.
 */
public interface Motor {

    List<GameObject> sceneObjects = new ArrayList<>();

    



}
