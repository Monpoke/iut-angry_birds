/*
 *  Projet AngryBirds
 *  DUT Informatique - 2e
 */
package angrybirds;

/**
 *
 * @author Pierre
 */
public class ObserverData {
    public String key = "";
    public int value;
}
