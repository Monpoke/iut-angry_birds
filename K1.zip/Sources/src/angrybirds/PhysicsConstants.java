/*
 *  Projet AngryBirds
 *  DUT Informatique - 2e
 */
package angrybirds;

/**
 * 
 * @author Pierre
 */
public abstract class PhysicsConstants {
    public static double G = 9.81;
}
